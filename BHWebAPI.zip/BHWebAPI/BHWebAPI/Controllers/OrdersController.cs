﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using BHWebAPI.Models;

namespace BHWebAPI.Controllers
{
    public class OrdersController : ApiController
    {
        private SrezDBEntities db = new SrezDBEntities();

        [Route("api/ServicesInOrder/{orderid}")]
        public IHttpActionResult ProductsInOrder(int orderid)
        {
            return Ok(db.getServicesByOrder(orderid).ToList());
        }

        [Route("api/getServicesInOrder/{orderid}")]
        public IHttpActionResult getServicesInOrder(int orderid)
        {
            return Ok(db.getServicesByOrder(orderid).ToList());
        }

        [Route("api/getOrderByUser/{userid}")]
        public IHttpActionResult getOrderByUser(int userid)
        {
            return Ok(db.getOrderByUser(userid).ToList());
        }

        [HttpPost]
        [Route("api/AddOrder/{clientid}", Name = "AddOrder")]
        public IHttpActionResult AddOrder(int clientid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            Random rand = new Random();
            int verifingcode = rand.Next(100, 999);
            db.addOrder(clientid);
            Order or = db.Order.OrderByDescending(x => x.OrderID).ToList()[0];
            int id = or.OrderID;
            return Ok(new
            {
                orderid = id
            });
        }

        [HttpPost]
        [Route("api/AddProductInOrder/{orderid}/{productid}", Name = "AddProductInOrder")]
        public IHttpActionResult AddProductInOrder(int orderid, int productid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.addServiceInOrder(productid, orderid);
            return Ok();
        }

        [HttpPost]
        [Route("api/deleteServiceInOrder/{orderid}/{productid}", Name = "deleteServiceInOrder")]
        public IHttpActionResult deleteServiceInOrder(int orderid, int productid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.deleteServiceInOrder(productid, orderid);
            return Ok();
        }

        [HttpPost]
        [Route("api/deleteOrder/{orderid}", Name = "deleteOrder")]
        public IHttpActionResult deleteOrder(int orderid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.deleteOrder(orderid);
            return Ok();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
